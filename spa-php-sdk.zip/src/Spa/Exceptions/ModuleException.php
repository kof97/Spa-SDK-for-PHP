<?php 

namespace Spa\Exceptions;

/**
 * Class ModuleException
 *
 * @category PHP
 * @package  Spa
 * @author	 Arno <arnoliu@tencent.com>
 */
class ModuleException extends SpaSDKException {

}

//end of script
