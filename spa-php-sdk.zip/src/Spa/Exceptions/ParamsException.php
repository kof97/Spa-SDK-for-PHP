<?php 

namespace Spa\Exceptions;

/**
 * Class ParamsException
 *
 * @category PHP
 * @package  Spa
 * @author	 Arno <arnoliu@tencent.com>
 */
class ParamsException extends SpaSDKException {

}

//end of script
