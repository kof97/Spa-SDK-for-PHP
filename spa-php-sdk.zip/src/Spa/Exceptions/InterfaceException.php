<?php 

namespace Spa\Exceptions;

/**
 * Class InterfaceException
 *
 * @category PHP
 * @package  Spa
 * @author	 Arno <arnoliu@tencent.com>
 */
class InterfaceException extends SpaSDKException {

}

//end of script
