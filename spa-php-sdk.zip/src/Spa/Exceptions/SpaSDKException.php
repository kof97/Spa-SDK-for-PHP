<?php 

namespace Spa\Exceptions;

/**
 * Class SpaSDKException
 *
 * @category PHP
 * @package  Spa
 * @author	 Arno <arnoliu@tencent.com>
 */
class SpaSDKException extends \Exception {

}

//end of script
