<?php 

namespace Spa\Url;

use Spa\Exceptions\SpaSDKException;

/**
 * Class UrlEndpointDetector
 *
 * @category PHP
 * @package  Spa
 * @author   Arno <arnoliu@tencent.com>
 */
class UrlEndpointDetector {

}

//end of script
