<?php 

namespace Spa\Object\Enum\Utility;

/**
 * Class IndustryTreeForAdgroupEnum
 *
 * @category PHP
 * @package  Spa
 * @author   Arno <arnoliu@tencent.com>
 */
class IndustryTreeForAdgroupEnum {
    
    
}

//end of script
