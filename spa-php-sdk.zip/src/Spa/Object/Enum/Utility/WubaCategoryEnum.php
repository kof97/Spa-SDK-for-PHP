<?php 

namespace Spa\Object\Enum\Utility;

/**
 * Class WubaCategoryEnum
 *
 * @category PHP
 * @package  Spa
 * @author   Arno <arnoliu@tencent.com>
 */
class WubaCategoryEnum {
    
    
}

//end of script
