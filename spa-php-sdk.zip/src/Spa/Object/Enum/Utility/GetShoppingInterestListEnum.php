<?php 

namespace Spa\Object\Enum\Utility;

/**
 * Class GetShoppingInterestListEnum
 *
 * @category PHP
 * @package  Spa
 * @author   Arno <arnoliu@tencent.com>
 */
class GetShoppingInterestListEnum {
    
    
}

//end of script
