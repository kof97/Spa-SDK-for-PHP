<?php 

namespace Spa\Object\Enum\Utility;

/**
 * Class GetRegionListEnum
 *
 * @category PHP
 * @package  Spa
 * @author   Arno <arnoliu@tencent.com>
 */
class GetRegionListEnum {
    
    
}

//end of script
