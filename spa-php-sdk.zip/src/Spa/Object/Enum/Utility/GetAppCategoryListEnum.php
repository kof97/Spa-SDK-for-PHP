<?php 

namespace Spa\Object\Enum\Utility;

/**
 * Class GetAppCategoryListEnum
 *
 * @category PHP
 * @package  Spa
 * @author   Arno <arnoliu@tencent.com>
 */
class GetAppCategoryListEnum {
    
    
}

//end of script
