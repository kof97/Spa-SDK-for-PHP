<?php 

namespace Spa\Object\Enum\Utility;

/**
 * Class GetBusinessInterestListEnum
 *
 * @category PHP
 * @package  Spa
 * @author   Arno <arnoliu@tencent.com>
 */
class GetBusinessInterestListEnum {
    
    
}

//end of script
