<?php 

namespace Spa\Object\Enum\Utility;

/**
 * Class GetSystemLocationRegionListEnum
 *
 * @category PHP
 * @package  Spa
 * @author   Arno <arnoliu@tencent.com>
 */
class GetSystemLocationRegionListEnum {
    
    
}

//end of script
