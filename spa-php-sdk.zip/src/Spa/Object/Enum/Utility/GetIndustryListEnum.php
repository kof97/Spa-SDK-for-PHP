<?php 

namespace Spa\Object\Enum\Utility;

/**
 * Class GetIndustryListEnum
 *
 * @category PHP
 * @package  Spa
 * @author   Arno <arnoliu@tencent.com>
 */
class GetIndustryListEnum {
    
    
}

//end of script
