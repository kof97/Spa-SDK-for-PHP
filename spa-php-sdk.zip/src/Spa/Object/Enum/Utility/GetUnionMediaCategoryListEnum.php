<?php 

namespace Spa\Object\Enum\Utility;

/**
 * Class GetUnionMediaCategoryListEnum
 *
 * @category PHP
 * @package  Spa
 * @author   Arno <arnoliu@tencent.com>
 */
class GetUnionMediaCategoryListEnum {
    
    
}

//end of script
