<?php 

namespace Spa\Object\Enum\Agency;

/**
 * Class GetFinancialOverviewEnum
 *
 * @category PHP
 * @package  Spa
 * @author   Arno <arnoliu@tencent.com>
 */
class GetFinancialOverviewEnum {
    
    
}

//end of script
