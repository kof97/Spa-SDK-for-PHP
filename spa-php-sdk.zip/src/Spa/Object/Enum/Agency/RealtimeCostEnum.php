<?php 

namespace Spa\Object\Enum\Agency;

/**
 * Class RealtimeCostEnum
 *
 * @category PHP
 * @package  Spa
 * @author   Arno <arnoliu@tencent.com>
 */
class RealtimeCostEnum {
    
    
}

//end of script
